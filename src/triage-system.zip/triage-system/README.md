# AI-Based Emergency Patient Prioritization and Resource Optimization

FastAPI + ML backend and React dashboard. Nurses register patients and record vitals, an ML model scores severity,
a live queue re-ranks patients, doctors can override the AI, and every override is used to retrain the model.

## Quick start (VS Code, two terminals)

**Terminal 1: backend** (no database install needed, it uses SQLite by default)
```bash
cd backend
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
python -m scripts.seed_demo       # optional: adds 12 demo patients (also trains the first model)
uvicorn app.main:app --reload
```
API docs: http://localhost:8000/docs. The first start generates the synthetic dataset and trains the model automatically.

**Terminal 2: frontend** (needs Node 18+)
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173.

## Demo accounts (demo only, change before any real use)
| Role | Username | Password | Can do |
|---|---|---|---|
| nurse | nurse | nurse123 | register patients, record vitals |
| doctor | doctor | doctor123 | treat/discharge, override AI tier |
| admin | admin | admin123 | register, stats, retrain model |

## Demo script for your review
1. Log in as **nurse**, register a patient, record vitals, see the AI tier and score.
2. Open a second browser window as **doctor**: the queue updates live (WebSocket).
3. As doctor, **override** a tier with a reason. The row is marked and the queue re-orders.
4. Repeat for ~10 overrides, then as **admin** click **Retrain from feedback** (or **Force retrain**).
   The model version goes up; an old model is kept in `backend/models/versions/`.

## How it works
- **Data:** `app/ml/data.py` generates synthetic vitals per tier (ESI-inspired, overlapping so accuracy is realistic).
- **Model:** XGBoost (falls back to scikit-learn gradient boosting if xgboost is missing). Score = probability-weighted tier score.
- **Queue:** ranked by score plus a small waiting-time bonus (capped, so it never jumps a whole tier).
- **Feedback loop:** `app/ml/retrain.py` turns each override into a labelled example (vitals + doctor's tier),
  weights it x5, retrains, and only swaps the model if Critical recall does not drop (validation gate).
- **Database:** SQLite by default. For PostgreSQL set `DATABASE_URL` in `backend/.env` and `pip install psycopg2-binary`.

## Tests
```bash
cd backend && pytest
```

## Structure
```
backend/app/   main.py routes.py services.py models.py schemas.py security.py ws.py database.py
backend/app/ml/ data.py train.py scorer.py retrain.py common.py
backend/scripts/seed_demo.py      backend/tests/
frontend/src/  App.jsx api.js components/{Login,Intake,Queue,Admin}.jsx
```

## Limitations (state these in your report)
Trained on synthetic data only. Real use needs clinical validation, bias auditing and human oversight.
