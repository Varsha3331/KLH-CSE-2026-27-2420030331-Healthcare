import uuid
from datetime import datetime, timezone
from sqlalchemy import Boolean, Column, DateTime, Float, ForeignKey, Integer, String
from .database import Base


def _id():
    return str(uuid.uuid4())


def _now():
    return datetime.now(timezone.utc).replace(tzinfo=None)


class User(Base):
    __tablename__ = "users"
    id = Column(String(36), primary_key=True, default=_id)
    username = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)
    full_name = Column(String)
    role = Column(String, nullable=False)  # doctor / nurse / admin


class Patient(Base):
    __tablename__ = "patients"
    id = Column(String(36), primary_key=True, default=_id)
    case_id = Column(String, unique=True, nullable=False)
    name = Column(String, nullable=False)
    age = Column(Integer)
    chief_complaint = Column(String)
    status = Column(String, default="waiting")  # waiting / in_treatment / discharged
    arrival_time = Column(DateTime, default=_now)


class VitalsRecord(Base):
    __tablename__ = "vitals_records"
    id = Column(String(36), primary_key=True, default=_id)
    patient_id = Column(String(36), ForeignKey("patients.id"), nullable=False)
    heart_rate = Column(Integer)
    bp_systolic = Column(Integer)
    bp_diastolic = Column(Integer)
    spo2 = Column(Float)
    respiratory_rate = Column(Integer)
    temperature = Column(Float)
    symptoms = Column(String)
    recorded_at = Column(DateTime, default=_now)


class TriageScore(Base):
    __tablename__ = "triage_scores"
    id = Column(String(36), primary_key=True, default=_id)
    patient_id = Column(String(36), ForeignKey("patients.id"), nullable=False)
    vitals_id = Column(String(36), ForeignKey("vitals_records.id"))
    score = Column(Float)
    priority_tier = Column(String)  # Critical / Urgent / Standard / Non-urgent
    model_version = Column(String)
    overridden = Column(Boolean, default=False)
    computed_at = Column(DateTime, default=_now)


class OverrideLog(Base):
    __tablename__ = "override_logs"
    id = Column(String(36), primary_key=True, default=_id)
    score_id = Column(String(36), ForeignKey("triage_scores.id"), nullable=False)
    staff_id = Column(String(36), ForeignKey("users.id"), nullable=False)
    original_tier = Column(String)
    original_score = Column(Float)
    new_tier = Column(String)  # doctor's corrected label = training signal
    new_score = Column(Float)
    reason = Column(String)
    used_in_retraining = Column(Integer, default=0)
    overridden_at = Column(DateTime, default=_now)
