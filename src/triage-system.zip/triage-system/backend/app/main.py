import os
from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from .database import Base, SessionLocal, engine
from .ml.train import ensure_model
from .models import User
from .routes import router
from .security import hash_pw
from .ws import manager

DEMO_USERS = [("doctor", "doctor123", "Dr. Rao", "doctor"),
              ("nurse", "nurse123", "Nurse Priya", "nurse"),
              ("admin", "admin123", "Admin", "admin")]


def seed_users():
    db = SessionLocal()
    if db.query(User).count() == 0:
        for u, pw, name, role in DEMO_USERS:
            db.add(User(username=u, password_hash=hash_pw(pw), full_name=name, role=role))
        db.commit()
    db.close()


@asynccontextmanager
async def lifespan(app):
    Base.metadata.create_all(bind=engine)
    seed_users()
    ensure_model()  # trains the first model automatically if missing
    yield


app = FastAPI(title="AI Emergency Triage System", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(","),
    allow_methods=["*"], allow_headers=["*"],
)
app.include_router(router)


@app.get("/")
def root():
    return {"status": "Triage API running", "docs": "/docs"}


@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await manager.connect(ws)
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(ws)
