from typing import Literal, Optional
from pydantic import BaseModel, Field

Tier = Literal["Critical", "Urgent", "Standard", "Non-urgent"]


class LoginIn(BaseModel):
    username: str
    password: str


class PatientIn(BaseModel):
    name: str = Field(min_length=1)
    age: Optional[int] = Field(default=None, ge=0, le=120)
    chief_complaint: str = ""


class VitalsIn(BaseModel):
    heart_rate: int = Field(ge=20, le=250)
    bp_systolic: int = Field(ge=40, le=260)
    bp_diastolic: int = Field(ge=20, le=160)
    spo2: float = Field(ge=50, le=100)
    respiratory_rate: int = Field(ge=4, le=70)
    temperature: float = Field(ge=30, le=45)
    symptoms: str = ""


class OverrideIn(BaseModel):
    score_id: str
    new_tier: Tier
    reason: str = Field(min_length=1)


class StatusIn(BaseModel):
    status: Literal["waiting", "in_treatment", "discharged"]
