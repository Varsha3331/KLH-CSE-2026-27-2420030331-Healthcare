from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session
from . import models as m, schemas, services
from .database import get_db
from .ml import retrain as retrain_mod, scorer
from .security import current_user, hash_pw, make_token, require, verify_pw
from .ws import manager

router = APIRouter()


@router.post("/auth/login")
def login(body: schemas.LoginIn, db: Session = Depends(get_db)):
    u = db.query(m.User).filter_by(username=body.username).first()
    if not u or not verify_pw(body.password, u.password_hash):
        raise HTTPException(401, "Wrong username or password")
    return {"token": make_token(u), "role": u.role, "name": u.full_name}


@router.post("/patients")
async def register_patient(body: schemas.PatientIn, db: Session = Depends(get_db),
                           _=Depends(require("nurse", "admin"))):
    p = services.create_patient(db, body.name, body.age, body.chief_complaint)
    await manager.broadcast()
    return {"id": p.id, "case_id": p.case_id, "name": p.name}


@router.post("/patients/{patient_id}/vitals")
async def record_vitals(patient_id: str, body: schemas.VitalsIn, db: Session = Depends(get_db),
                        _=Depends(require("nurse", "doctor", "admin"))):
    s = services.add_vitals(db, patient_id, body.model_dump())
    if not s:
        raise HTTPException(404, "Patient not found")
    await manager.broadcast()
    return {"score_id": s.id, "tier": s.priority_tier, "score": s.score, "model_version": s.model_version}


@router.get("/queue")
def get_queue(db: Session = Depends(get_db), _=Depends(current_user)):
    return services.build_queue(db)


@router.post("/patients/{patient_id}/status")
async def set_status(patient_id: str, body: schemas.StatusIn, db: Session = Depends(get_db),
                     _=Depends(require("doctor", "admin"))):
    p = db.get(m.Patient, patient_id)
    if not p:
        raise HTTPException(404, "Patient not found")
    p.status = body.status
    db.commit()
    await manager.broadcast()
    return {"ok": True}


@router.post("/overrides")
async def override(body: schemas.OverrideIn, db: Session = Depends(get_db),
                   user=Depends(require("doctor"))):
    log = services.apply_override(db, body.score_id, user.id, body.new_tier, body.reason)
    if not log:
        raise HTTPException(404, "Score not found")
    await manager.broadcast()
    return {"override_logged": True, "from": log.original_tier, "to": log.new_tier}


@router.get("/overrides")
def list_overrides(db: Session = Depends(get_db), _=Depends(require("doctor", "admin"))):
    rows = db.query(m.OverrideLog).order_by(m.OverrideLog.overridden_at.desc()).limit(50).all()
    return [{"from": r.original_tier, "to": r.new_tier, "reason": r.reason,
             "used_in_retraining": bool(r.used_in_retraining),
             "at": r.overridden_at.isoformat()} for r in rows]


@router.get("/admin/stats")
def stats(db: Session = Depends(get_db), _=Depends(require("admin", "doctor"))):
    queue = services.build_queue(db)
    by_tier = {}
    for i in queue:
        by_tier[i["tier"] or "Awaiting vitals"] = by_tier.get(i["tier"] or "Awaiting vitals", 0) + 1
    waits = [i["wait_min"] for i in queue]
    return {
        "active_patients": len(queue), "by_tier": by_tier,
        "avg_wait_min": round(sum(waits) / len(waits), 1) if waits else 0,
        "overrides_total": db.query(func.count(m.OverrideLog.id)).scalar(),
        "overrides_pending": db.query(func.count(m.OverrideLog.id))
                               .filter(m.OverrideLog.used_in_retraining == 0).scalar(),
        "model": scorer.meta(),
    }


@router.post("/admin/retrain")
def retrain(force: bool = False, db: Session = Depends(get_db), _=Depends(require("admin"))):
    return retrain_mod.retrain(db, force=force)
