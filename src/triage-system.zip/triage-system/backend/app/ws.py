from fastapi import WebSocket


class Manager:
    def __init__(self):
        self.conns: list[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.conns.append(ws)

    def disconnect(self, ws: WebSocket):
        if ws in self.conns:
            self.conns.remove(ws)

    async def broadcast(self, message: str = "queue_changed"):
        for ws in list(self.conns):
            try:
                await ws.send_text(message)
            except Exception:
                self.disconnect(ws)


manager = Manager()
