import uuid
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from . import models as m
from .ml import scorer
from .ml.common import TIER_SCORE

AGING_PER_MIN = 0.1   # waiting patients slowly rise in the queue...
AGING_CAP = 9.0       # ...but never enough to jump a whole tier


def now():
    return datetime.now(timezone.utc).replace(tzinfo=None)


def create_patient(db: Session, name: str, age, chief_complaint: str) -> m.Patient:
    p = m.Patient(name=name, age=age, chief_complaint=chief_complaint,
                  case_id="CASE-" + uuid.uuid4().hex[:8].upper())
    db.add(p)
    db.commit()
    db.refresh(p)
    return p


def add_vitals(db: Session, patient_id: str, data: dict):
    if not db.get(m.Patient, patient_id):
        return None
    v = m.VitalsRecord(patient_id=patient_id, **data)
    db.add(v)
    db.flush()
    r = scorer.score(data["heart_rate"], data["bp_systolic"], data["spo2"],
                     data["respiratory_rate"], data["temperature"])
    s = m.TriageScore(patient_id=patient_id, vitals_id=v.id, score=r["score"],
                      priority_tier=r["priority_tier"], model_version=r["model_version"])
    db.add(s)
    db.commit()
    db.refresh(s)
    return s


def latest_score(db: Session, patient_id: str):
    return (db.query(m.TriageScore).filter_by(patient_id=patient_id)
            .order_by(m.TriageScore.computed_at.desc()).first())


def build_queue(db: Session) -> list:
    items = []
    for p in db.query(m.Patient).filter(m.Patient.status != "discharged").all():
        s = latest_score(db, p.id)
        v = db.get(m.VitalsRecord, s.vitals_id) if s and s.vitals_id else None
        wait = (now() - p.arrival_time).total_seconds() / 60
        eff = (s.score + min(wait * AGING_PER_MIN, AGING_CAP)) if s else -1
        items.append({
            "patient_id": p.id, "case_id": p.case_id, "name": p.name, "age": p.age,
            "chief_complaint": p.chief_complaint, "status": p.status,
            "score_id": s.id if s else None, "tier": s.priority_tier if s else None,
            "score": s.score if s else None, "priority": round(eff, 1),
            "overridden": bool(s.overridden) if s else False,
            "wait_min": int(wait),
            "vitals": None if not v else {
                "hr": v.heart_rate, "bp": f"{v.bp_systolic}/{v.bp_diastolic}", "spo2": v.spo2,
                "rr": v.respiratory_rate, "temp": v.temperature, "symptoms": v.symptoms},
        })
    items.sort(key=lambda i: (i["status"] == "in_treatment", -i["priority"]))
    for n, i in enumerate(items, 1):
        i["rank"] = n
    return items


def apply_override(db: Session, score_id: str, staff_id: str, new_tier: str, reason: str):
    s = db.get(m.TriageScore, score_id)
    if not s:
        return None
    log = m.OverrideLog(score_id=s.id, staff_id=staff_id, original_tier=s.priority_tier,
                        original_score=s.score, new_tier=new_tier,
                        new_score=TIER_SCORE[new_tier], reason=reason)
    s.priority_tier = new_tier
    s.score = TIER_SCORE[new_tier]
    s.overridden = True
    db.add(log)
    db.commit()
    return log
