import numpy as np
import pandas as pd

# (hr, sbp, spo2, rr, temp) means and std devs per tier - loosely ESI-inspired
PROFILES = {
    "Critical":   ([130, 80, 85, 30, 39.5], [15, 15, 5, 5, 1.0]),
    "Urgent":     ([110, 100, 92, 24, 38.5], [12, 12, 3, 4, 0.8]),
    "Standard":   ([90, 115, 96, 18, 37.5], [10, 10, 2, 3, 0.5]),
    "Non-urgent": ([75, 120, 98, 15, 36.8], [8, 8, 1, 2, 0.3]),
}
PRIORS = [0.08, 0.22, 0.40, 0.30]  # rare critical cases, like a real ED
NOISE = 1.1  # widens spread so tiers overlap (avoids unrealistically perfect accuracy)


def generate(n: int = 5000, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    tiers = rng.choice(list(PROFILES), size=n, p=PRIORS)
    rows = []
    for t in tiers:
        mu, sd = PROFILES[t]
        hr, sbp, spo2, rr, temp = rng.normal(mu, np.array(sd) * NOISE)
        rows.append({
            "heart_rate": int(max(30, round(hr))),
            "bp_systolic": int(max(40, round(sbp))),
            "spo2": float(min(100, max(50, round(spo2, 1)))),
            "respiratory_rate": int(max(6, round(rr))),
            "temperature": float(round(temp, 1)),
            "priority_tier": t,
        })
    return pd.DataFrame(rows)
