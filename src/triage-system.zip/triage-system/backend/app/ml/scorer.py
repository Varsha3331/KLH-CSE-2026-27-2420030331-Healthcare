import json
import joblib
import pandas as pd
from .common import ENC_PATH, FEATURES, META_PATH, MODEL_PATH, TIER_SCORE

_cache = {}


def _load():
    if not _cache:
        _cache.update(model=joblib.load(MODEL_PATH), enc=joblib.load(ENC_PATH),
                      meta=json.loads(META_PATH.read_text()))
    return _cache


def reload():
    _cache.clear()
    return _load()


def meta() -> dict:
    return _load()["meta"]


def score(heart_rate, bp_systolic, spo2, respiratory_rate, temperature) -> dict:
    c = _load()
    X = pd.DataFrame([[heart_rate, bp_systolic, spo2, respiratory_rate, temperature]], columns=FEATURES)
    proba = c["model"].predict_proba(X)[0]
    classes = list(c["enc"].classes_)
    tier = classes[int(proba.argmax())]
    # probability-weighted score gives a smooth ranking inside each tier
    s = sum(p * TIER_SCORE[cl] for p, cl in zip(proba, classes))
    return {"priority_tier": tier, "score": round(float(s), 1),
            "model_version": f"v{c['meta']['version']}"}
