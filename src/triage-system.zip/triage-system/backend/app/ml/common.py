from pathlib import Path

BASE = Path(__file__).resolve().parents[2]  # backend/
MODELS_DIR = BASE / "models"
DATA_DIR = BASE / "data"
MODEL_PATH = MODELS_DIR / "triage_model.pkl"
ENC_PATH = MODELS_DIR / "label_encoder.pkl"
META_PATH = MODELS_DIR / "meta.json"
DATA_PATH = DATA_DIR / "synthetic_triage_data.csv"

FEATURES = ["heart_rate", "bp_systolic", "spo2", "respiratory_rate", "temperature"]
TIERS = ["Critical", "Urgent", "Standard", "Non-urgent"]
TIER_SCORE = {"Critical": 100, "Urgent": 75, "Standard": 40, "Non-urgent": 10}


def make_model():
    """XGBoost if installed, otherwise scikit-learn gradient boosting."""
    try:
        from xgboost import XGBClassifier
        return XGBClassifier(n_estimators=200, max_depth=4, learning_rate=0.1,
                             eval_metric="mlogloss", random_state=42)
    except ImportError:
        from sklearn.ensemble import GradientBoostingClassifier
        return GradientBoostingClassifier(random_state=42)
