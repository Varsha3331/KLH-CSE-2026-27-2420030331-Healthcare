import os
import joblib
import pandas as pd
from sqlalchemy.orm import Session
from .. import models as m
from . import scorer
from .common import DATA_DIR, DATA_PATH, ENC_PATH, MODEL_PATH
from .data import generate
from .train import evaluate, fit, save

MIN_FEEDBACK = int(os.getenv("RETRAIN_MIN", "10"))
MAX_RECALL_DROP = 0.02  # validation gate on Critical recall


def pending_feedback(db: Session):
    rows, logs = [], []
    for log in db.query(m.OverrideLog).filter(m.OverrideLog.used_in_retraining == 0).all():
        sc = db.get(m.TriageScore, log.score_id)
        v = db.get(m.VitalsRecord, sc.vitals_id) if sc and sc.vitals_id else None
        if v:
            rows.append({"heart_rate": v.heart_rate, "bp_systolic": v.bp_systolic, "spo2": v.spo2,
                         "respiratory_rate": v.respiratory_rate, "temperature": v.temperature,
                         "priority_tier": log.new_tier})
            logs.append(log)
    return rows, logs


def retrain(db: Session, force: bool = False) -> dict:
    rows, logs = pending_feedback(db)
    if len(rows) < MIN_FEEDBACK and not force:
        return {"status": "skipped", "feedback_examples": len(rows), "needed": MIN_FEEDBACK}
    DATA_DIR.mkdir(exist_ok=True)
    if not DATA_PATH.exists():
        generate().to_csv(DATA_PATH, index=False)
    model, enc, Xte, yte = fit(pd.read_csv(DATA_PATH), pd.DataFrame(rows))
    new = evaluate(model, enc, Xte, yte)
    old = evaluate(joblib.load(MODEL_PATH), joblib.load(ENC_PATH), Xte, yte)
    if new["critical_recall"] < old["critical_recall"] - MAX_RECALL_DROP:
        return {"status": "rejected", "reason": "Critical recall dropped; old model kept",
                "old": old, "new": new}
    meta = save(model, enc, new, note=f"retrained on {len(rows)} doctor corrections")
    scorer.reload()
    for log in logs:
        log.used_in_retraining = 1
    db.commit()
    return {"status": "updated", "feedback_examples": len(rows), "old": old, "new": new,
            "version": meta["version"]}
