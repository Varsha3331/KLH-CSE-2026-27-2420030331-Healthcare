import json
import shutil
from datetime import datetime
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from .common import (DATA_DIR, DATA_PATH, ENC_PATH, FEATURES, META_PATH, MODEL_PATH,
                     MODELS_DIR, TIERS, make_model)
from .data import generate

FEEDBACK_WEIGHT = 5  # doctor corrections count more than synthetic rows


def fit(base_df: pd.DataFrame, feedback_df: pd.DataFrame = None):
    """Train on base data (+ weighted feedback in the TRAIN split only). Test split = base only."""
    enc = LabelEncoder().fit(TIERS)
    y = enc.transform(base_df["priority_tier"])
    Xtr, Xte, ytr, yte = train_test_split(base_df[FEATURES], y, test_size=0.2,
                                          stratify=y, random_state=42)
    if feedback_df is not None and len(feedback_df):
        fb = pd.concat([feedback_df] * FEEDBACK_WEIGHT, ignore_index=True)
        Xtr = pd.concat([Xtr, fb[FEATURES]], ignore_index=True)
        ytr = np.concatenate([ytr, enc.transform(fb["priority_tier"])])
    model = make_model().fit(Xtr, ytr)
    return model, enc, Xte, yte


def evaluate(model, enc, X, y) -> dict:
    pred = model.predict(X)
    ci = int(enc.transform(["Critical"])[0])
    return {"accuracy": round(float((pred == y).mean()), 4),
            "critical_recall": round(float((pred[y == ci] == ci).mean()), 4)}


def save(model, enc, metrics: dict, note: str = "initial training") -> dict:
    MODELS_DIR.mkdir(exist_ok=True)
    version = 1
    if META_PATH.exists():
        version = json.loads(META_PATH.read_text())["version"] + 1
        (MODELS_DIR / "versions").mkdir(exist_ok=True)
        shutil.copy(MODEL_PATH, MODELS_DIR / "versions" / f"triage_model_v{version - 1}.pkl")
    joblib.dump(model, MODEL_PATH)
    joblib.dump(enc, ENC_PATH)
    meta = {"version": version, "trained_at": datetime.now().isoformat(timespec="seconds"),
            "note": note, **metrics}
    META_PATH.write_text(json.dumps(meta, indent=2))
    return meta


def ensure_model():
    """Generate synthetic data and train the first model if none exists yet."""
    if MODEL_PATH.exists() and META_PATH.exists():
        return
    DATA_DIR.mkdir(exist_ok=True)
    if not DATA_PATH.exists():
        generate().to_csv(DATA_PATH, index=False)
    model, enc, Xte, yte = fit(pd.read_csv(DATA_PATH))
    print("Initial model trained:", save(model, enc, evaluate(model, enc, Xte, yte)))


if __name__ == "__main__":
    ensure_model()
