from app.ml.data import generate
from app.ml.train import evaluate, fit


def test_model_separates_extremes():
    df = generate(3000)
    model, enc, Xte, yte = fit(df)
    m = evaluate(model, enc, Xte, yte)
    assert m["accuracy"] > 0.8 and m["critical_recall"] > 0.7


def test_feedback_is_used():
    import pandas as pd
    df = generate(2000)
    fb = pd.DataFrame([{"heart_rate": 75, "bp_systolic": 120, "spo2": 98, "respiratory_rate": 15,
                        "temperature": 36.8, "priority_tier": "Critical"}] * 20)
    model, enc, _, _ = fit(df, fb)
    pred = enc.inverse_transform(model.predict(fb[["heart_rate", "bp_systolic", "spo2",
                                                    "respiratory_rate", "temperature"]].head(1)))[0]
    assert pred == "Critical"  # doctor corrections shift the model
