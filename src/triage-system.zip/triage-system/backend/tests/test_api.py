import os
os.environ["DATABASE_URL"] = "sqlite:///./test_triage.db"
from fastapi.testclient import TestClient
from app.main import app


def auth(c, u, p):
    t = c.post("/auth/login", json={"username": u, "password": p}).json()["token"]
    return {"Authorization": f"Bearer {t}"}


def test_full_flow():
    with TestClient(app) as c:
        nurse, doctor = auth(c, "nurse", "nurse123"), auth(c, "doctor", "doctor123")
        crit = c.post("/patients", json={"name": "A", "age": 50, "chief_complaint": "x"}, headers=nurse).json()
        ok = c.post("/patients", json={"name": "B", "age": 20, "chief_complaint": "y"}, headers=nurse).json()
        v = lambda hr, s, sp, rr, t: {"heart_rate": hr, "bp_systolic": s, "bp_diastolic": 60,
                                       "spo2": sp, "respiratory_rate": rr, "temperature": t, "symptoms": ""}
        r1 = c.post(f"/patients/{crit['id']}/vitals", json=v(135, 78, 84, 32, 39.8), headers=nurse).json()
        c.post(f"/patients/{ok['id']}/vitals", json=v(72, 120, 98, 14, 36.7), headers=nurse)
        q = c.get("/queue", headers=nurse).json()
        assert q[0]["name"] == "A" and r1["tier"] == "Critical"
        assert c.post("/overrides", json={"score_id": r1["score_id"], "new_tier": "Urgent", "reason": "t"},
                      headers=nurse).status_code == 403
        assert c.post("/overrides", json={"score_id": r1["score_id"], "new_tier": "Urgent", "reason": "t"},
                      headers=doctor).status_code == 200
