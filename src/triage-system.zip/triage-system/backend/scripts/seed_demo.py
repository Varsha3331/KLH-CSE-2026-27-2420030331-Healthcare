"""Fill the database with demo patients so the dashboard isn't empty.  Run from backend/:  python -m scripts.seed_demo"""
import random
from app.database import Base, SessionLocal, engine
from app.main import seed_users
from app.ml.data import generate
from app.ml.train import ensure_model
from app import services

NAMES = ["Anil K", "Meena R", "Ravi T", "Sana S", "Kiran P", "Lakshmi D", "Arjun V", "Fatima B",
         "Suresh N", "Divya M", "Rahul G", "Pooja H"]
COMPLAINTS = ["Chest pain", "Breathlessness", "High fever", "Road accident", "Abdominal pain",
              "Headache", "Minor cut", "Vomiting", "Back pain", "Dizziness"]

Base.metadata.create_all(bind=engine)
seed_users()
ensure_model()
db = SessionLocal()
for name, (_, row) in zip(NAMES, generate(len(NAMES), seed=random.randint(1, 9999)).iterrows()):
    p = services.create_patient(db, name, random.randint(8, 80), random.choice(COMPLAINTS))
    services.add_vitals(db, p.id, {
        "heart_rate": int(row.heart_rate), "bp_systolic": int(row.bp_systolic),
        "bp_diastolic": max(30, int(row.bp_systolic) - 40), "spo2": float(row.spo2),
        "respiratory_rate": int(row.respiratory_rate), "temperature": float(row.temperature),
        "symptoms": ""})
print(f"Seeded {len(NAMES)} demo patients.")
db.close()
