import { useState } from "react";
import { api, setToken } from "../api";

const DEMO = [["doctor", "doctor123"], ["nurse", "nurse123"], ["admin", "admin123"]];

export default function Login({ onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    try {
      const r = await api("/auth/login", "POST", { username, password });
      setToken(r.token);
      onLogin({ name: r.name, role: r.role });
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="login">
      <form onSubmit={submit} className="card">
        <h2>Emergency Triage System</h2>
        <input placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} />
        <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
        <button type="submit">Log in</button>
        {error && <p className="error">{error}</p>}
        <p className="hint">
          Demo accounts:{" "}
          {DEMO.map(([u, p]) => (
            <a key={u} href="#" onClick={(e) => { e.preventDefault(); setUsername(u); setPassword(p); }}>{u} </a>
          ))}
        </p>
      </form>
    </div>
  );
}
