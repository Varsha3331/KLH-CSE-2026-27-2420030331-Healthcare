import { useEffect, useState } from "react";
import { api } from "../api";

const EMPTY_V = { heart_rate: "", bp_systolic: "", bp_diastolic: "", spo2: "", respiratory_rate: "", temperature: "", symptoms: "" };

export default function Intake() {
  const [p, setP] = useState({ name: "", age: "", chief_complaint: "" });
  const [v, setV] = useState(EMPTY_V);
  const [patients, setPatients] = useState([]);
  const [selected, setSelected] = useState("");
  const [msg, setMsg] = useState("");

  const load = () => api("/queue").then((q) => setPatients(q)).catch(() => {});
  useEffect(() => { load(); }, []);

  const register = async (e) => {
    e.preventDefault();
    try {
      const r = await api("/patients", "POST", { name: p.name, age: p.age ? Number(p.age) : null, chief_complaint: p.chief_complaint });
      setMsg(`Registered ${r.name} (${r.case_id}). Now record vitals.`);
      setP({ name: "", age: "", chief_complaint: "" });
      await load();
      setSelected(r.id);
    } catch (err) { setMsg(err.message); }
  };

  const submitVitals = async (e) => {
    e.preventDefault();
    if (!selected) return setMsg("Select a patient first.");
    try {
      const body = { ...Object.fromEntries(Object.entries(v).filter(([k]) => k !== "symptoms").map(([k, x]) => [k, Number(x)])), symptoms: v.symptoms };
      const r = await api(`/patients/${selected}/vitals`, "POST", body);
      setMsg(`AI triage result: ${r.tier} (score ${r.score}, model ${r.model_version})`);
      setV(EMPTY_V);
      load();
    } catch (err) { setMsg(err.message); }
  };

  const num = (k, label, step) => (
    <input key={k} type="number" step={step || 1} placeholder={label} value={v[k]} onChange={(e) => setV({ ...v, [k]: e.target.value })} required />
  );

  return (
    <section className="grid2">
      <form className="card" onSubmit={register}>
        <h2>1. Register patient</h2>
        <input placeholder="Name" value={p.name} onChange={(e) => setP({ ...p, name: e.target.value })} required />
        <input type="number" placeholder="Age" value={p.age} onChange={(e) => setP({ ...p, age: e.target.value })} />
        <input placeholder="Chief complaint" value={p.chief_complaint} onChange={(e) => setP({ ...p, chief_complaint: e.target.value })} />
        <button type="submit">Register</button>
      </form>
      <form className="card" onSubmit={submitVitals}>
        <h2>2. Record vitals</h2>
        <select value={selected} onChange={(e) => setSelected(e.target.value)}>
          <option value="">Select patient…</option>
          {patients.map((x) => <option key={x.patient_id} value={x.patient_id}>{x.case_id} – {x.name}</option>)}
        </select>
        <div className="row">{num("heart_rate", "Heart rate (bpm)")}{num("respiratory_rate", "Resp. rate")}</div>
        <div className="row">{num("bp_systolic", "BP systolic")}{num("bp_diastolic", "BP diastolic")}</div>
        <div className="row">{num("spo2", "SpO2 %", 0.1)}{num("temperature", "Temp °C", 0.1)}</div>
        <input placeholder="Symptoms (optional)" value={v.symptoms} onChange={(e) => setV({ ...v, symptoms: e.target.value })} />
        <button type="submit">Score patient</button>
      </form>
      {msg && <p className="msg">{msg}</p>}
    </section>
  );
}
