import { useEffect, useState } from "react";
import { api } from "../api";

export default function Admin() {
  const [s, setS] = useState(null);
  const [result, setResult] = useState("");
  const load = () => api("/admin/stats").then(setS).catch(() => {});
  useEffect(() => { load(); }, []);

  const retrain = async (force) => {
    setResult("Retraining…");
    try {
      const r = await api("/admin/retrain" + (force ? "?force=true" : ""), "POST");
      setResult(JSON.stringify(r));
      load();
    } catch (e) { setResult(e.message); }
  };

  if (!s) return null;
  return (
    <section className="card">
      <h2>Admin: load &amp; model</h2>
      <div className="stats">
        <div><b>{s.active_patients}</b><small>active patients</small></div>
        <div><b>{s.avg_wait_min}</b><small>avg wait (min)</small></div>
        <div><b>{s.overrides_total}</b><small>doctor overrides</small></div>
        <div><b>{s.overrides_pending}</b><small>waiting for retrain</small></div>
        <div><b>v{s.model.version}</b><small>model · acc {s.model.accuracy} · critical recall {s.model.critical_recall}</small></div>
      </div>
      <p>{Object.entries(s.by_tier).map(([k, n]) => `${k}: ${n}`).join("  |  ")}</p>
      <button onClick={() => retrain(false)}>Retrain from feedback</button>{" "}
      <button className="ghost" onClick={() => retrain(true)}>Force retrain</button>
      {result && <p className="msg">{result}</p>}
    </section>
  );
}
