import { useCallback, useEffect, useState } from "react";
import { api, wsUrl } from "../api";

const TIERS = ["Critical", "Urgent", "Standard", "Non-urgent"];

function Row({ item, role, onChange }) {
  const [tier, setTier] = useState(item.tier || "Urgent");
  const [reason, setReason] = useState("");
  const [err, setErr] = useState("");

  const override = async () => {
    try {
      await api("/overrides", "POST", { score_id: item.score_id, new_tier: tier, reason });
      setReason("");
      setErr("");
      onChange();
    } catch (e) { setErr(e.message); }
  };
  const setStatus = (status) => api(`/patients/${item.patient_id}/status`, "POST", { status }).then(onChange);

  return (
    <tr className={item.status === "in_treatment" ? "treating" : ""}>
      <td>{item.rank}</td>
      <td><b>{item.name}</b><br /><small>{item.case_id} · {item.age ?? "?"}y</small></td>
      <td>{item.chief_complaint || "-"}</td>
      <td>{item.tier ? <span className={"tier tier-" + item.tier}>{item.tier}</span> : <em>awaiting vitals</em>}{item.overridden && <span title="Changed by doctor"> ✎</span>}</td>
      <td>{item.score ?? "-"}</td>
      <td>{item.vitals ? <small>HR {item.vitals.hr} · BP {item.vitals.bp} · SpO2 {item.vitals.spo2} · RR {item.vitals.rr} · {item.vitals.temp}°C</small> : "-"}</td>
      <td>{item.wait_min} min</td>
      <td>{item.status.replace("_", " ")}</td>
      {(role === "doctor" || role === "admin") && (
        <td className="actions">
          {item.status === "waiting" && <button onClick={() => setStatus("in_treatment")}>Treat</button>}
          <button className="ghost" onClick={() => setStatus("discharged")}>Discharge</button>
          {role === "doctor" && item.score_id && (
            <div className="override">
              <select value={tier} onChange={(e) => setTier(e.target.value)}>{TIERS.map((t) => <option key={t}>{t}</option>)}</select>
              <input placeholder="Reason for override" value={reason} onChange={(e) => setReason(e.target.value)} />
              <button disabled={!reason} onClick={override}>Override</button>
              {err && <small className="error">{err}</small>}
            </div>
          )}
        </td>
      )}
    </tr>
  );
}

export default function Queue({ role }) {
  const [queue, setQueue] = useState([]);
  const [live, setLive] = useState(false);
  const load = useCallback(() => api("/queue").then(setQueue).catch(() => {}), []);

  useEffect(() => {
    load();
    const ws = new WebSocket(wsUrl);
    ws.onopen = () => setLive(true);
    ws.onclose = () => setLive(false);
    ws.onmessage = load; // server says "queue_changed" -> refetch
    const t = setInterval(load, 30000); // keeps wait times fresh
    return () => { ws.close(); clearInterval(t); };
  }, [load]);

  const canAct = role === "doctor" || role === "admin";
  return (
    <section className="card">
      <h2>Live priority queue <span className={live ? "dot on" : "dot"} title={live ? "Live" : "Reconnecting"} /></h2>
      <div className="scroll">
        <table>
          <thead>
            <tr><th>#</th><th>Patient</th><th>Complaint</th><th>AI tier</th><th>Score</th><th>Vitals</th><th>Wait</th><th>Status</th>{canAct && <th>Actions</th>}</tr>
          </thead>
          <tbody>
            {queue.map((i) => <Row key={i.patient_id + i.score_id + i.tier + i.status} item={i} role={role} onChange={load} />)}
            {!queue.length && <tr><td colSpan={9}>No active patients.</td></tr>}
          </tbody>
        </table>
      </div>
    </section>
  );
}
