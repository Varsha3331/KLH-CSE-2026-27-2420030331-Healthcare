import { useState } from "react";
import { setToken } from "./api";
import Login from "./components/Login.jsx";
import Queue from "./components/Queue.jsx";
import Intake from "./components/Intake.jsx";
import Admin from "./components/Admin.jsx";

export default function App() {
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem("user") || "null"));

  const onLogin = (u) => {
    localStorage.setItem("user", JSON.stringify(u));
    setUser(u);
  };
  const logout = () => {
    setToken(null);
    localStorage.removeItem("user");
    setUser(null);
  };

  if (!user) return <Login onLogin={onLogin} />;

  return (
    <div className="page">
      <header>
        <h1>Emergency Triage Dashboard</h1>
        <div>
          {user.name} <span className={"role role-" + user.role}>{user.role}</span>
          <button className="ghost" onClick={logout}>Log out</button>
        </div>
      </header>
      {(user.role === "nurse" || user.role === "admin") && <Intake />}
      {user.role === "admin" && <Admin />}
      <Queue role={user.role} />
    </div>
  );
}
